package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q7: Check If Any Number is Even
//Methods Used: anyMatch()

public class Q7 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(11, 13, 15, 20);

        boolean hasEven = numbers.stream()
                                 .anyMatch(n -> n % 2 == 0);

        System.out.println("Contains even? " + hasEven);
    }
    //anyMatch() returns true if at least one element matches the condition
}
