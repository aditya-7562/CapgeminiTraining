package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q8: Find Employees Older Than 25
//Methods Used: filter(), forEach()

public class EmpQ8 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        employees.stream()
                .filter(emp -> emp.getAge() > 25)
                .forEach(System.out::println);
    }
    //filter() with age condition to get employees older than 25

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
