package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q5: Sort a List of Integers
//Methods Used: sorted()

public class Q5 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(40, 10, 30, 20);

        numbers.stream()
               .sorted()
               .forEach(System.out::println);
    }
    //sorted() sorts elements in natural (ascending) order
}
