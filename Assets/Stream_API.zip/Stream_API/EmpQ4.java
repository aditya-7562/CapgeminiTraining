package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q4: Find Average Salary
//Methods Used: mapToDouble(), average()

public class EmpQ4 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        double avgSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0);

        System.out.println("Average Salary: " + avgSalary);
    }
    //mapToDouble() converts to DoubleStream for numerical operations

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
