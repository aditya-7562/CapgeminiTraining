package Core_Java.Stream_API_Advanced_10;

import java.util.*;
import java.util.stream.*;

//Q4: Remove Duplicate Elements
//Methods Used: distinct(), collect()

public class Q4 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 2, 3, 4, 4, 5);

        List<Integer> unique = numbers.stream()
                                      .distinct()
                                      .collect(Collectors.toList());

        System.out.println(unique);
    }
    //distinct() removes duplicate elements from the stream
}
