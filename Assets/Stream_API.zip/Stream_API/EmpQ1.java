package Core_Java.Stream_API_Advanced_10;

import java.util.*;
import java.util.stream.*;

//Q1: Get Employees with Salary > 50,000
//Methods Used: filter(), collect()

public class EmpQ1 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        List<Employee> result = employees.stream()
                .filter(emp -> emp.getSalary() > 50000)
                .collect(Collectors.toList());

        result.forEach(System.out::println);
    }
    //Filters employees based on salary condition and collects them into a new list

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
