package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q9: Get Total Salary of All Employees
//Methods Used: mapToDouble(), sum()

public class EmpQ9 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        double totalSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .sum();

        System.out.println("Total Salary: " + totalSalary);
    }
    //sum() calculates the total of all salary values in the stream

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
