package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q6: Find the First Element Greater Than 50
//Methods Used: filter(), findFirst(), orElse()

public class Q6 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 20, 60, 70);

        int result = numbers.stream()
                            .filter(n -> n > 50)
                            .findFirst()
                            .orElse(-1);

        System.out.println("First number > 50: " + result);
    }
    //findFirst() returns Optional, orElse() provides default value if empty
}
