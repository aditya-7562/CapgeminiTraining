package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q9: Get Top 3 Largest Numbers
//Methods Used: sorted(), limit()

public class Q9 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 50, 30, 90, 70);

        numbers.stream()
               .sorted(Comparator.reverseOrder())
               .limit(3)
               .forEach(System.out::println);
    }
    //reverseOrder() sorts descending, limit(3) takes only first 3 elements
}
