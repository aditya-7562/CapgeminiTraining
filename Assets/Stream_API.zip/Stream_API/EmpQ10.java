package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q10: Check If Any Employee Belongs to HR
//Methods Used: anyMatch()

public class EmpQ10 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        boolean hasHR = employees.stream()
                .anyMatch(emp -> emp.getDepartment().equals("HR"));

        System.out.println("Has HR? " + hasHR);
    }
    //anyMatch() returns true if at least one element matches the condition

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
