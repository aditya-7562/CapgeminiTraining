package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q1: Print All Even Numbers from a List
//Methods Used: stream(), filter(), forEach()

public class Q1 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 15, 20, 25, 30);

        numbers.stream()
               .filter(n -> n % 2 == 0)
               .forEach(System.out::println);
    }
    //filter() keeps only elements that satisfy the condition (n % 2 == 0)
}
