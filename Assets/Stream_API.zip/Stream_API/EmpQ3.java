package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q3: Find Employee with Highest Salary
//Methods Used: max(), Comparator.comparing()

public class EmpQ3 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        Employee highest = employees.stream()
                .max(Comparator.comparing(Employee::getSalary))
                .orElse(null);

        System.out.println("Highest Paid: " + highest);
    }
    //max() returns Optional<Employee>, orElse() handles empty case

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
