package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q5: Count Employees in IT Department
//Methods Used: filter(), count()

public class EmpQ5 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        long count = employees.stream()
                .filter(emp -> emp.getDepartment().equals("IT"))
                .count();

        System.out.println("IT Employees: " + count);
    }
    //count() returns the number of elements in the stream

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
