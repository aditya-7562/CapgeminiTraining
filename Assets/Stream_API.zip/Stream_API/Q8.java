package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q8: Check If All Numbers Are Positive
//Methods Used: allMatch()

public class Q8 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(5, 10, 15);

        boolean allPositive = numbers.stream()
                                     .allMatch(n -> n > 0);

        System.out.println("All positive? " + allPositive);
    }
    //allMatch() returns true only if all elements match the condition
}
