package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q6: Sort Employees by Salary (Descending)
//Methods Used: sorted(), Comparator.reversed()

public class EmpQ6 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        employees.stream()
                .sorted(Comparator.comparing(Employee::getSalary).reversed())
                .forEach(System.out::println);
    }
    //reversed() reverses the natural ordering for descending sort

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
