package Core_Java.Stream_API_Advanced_10;

import java.util.*;
import java.util.stream.*;

//Q2: Convert All Strings to Uppercase
//Methods Used: map(), collect()

public class Q2 {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("varshini", "ram", "john");

        List<String> upperNames = names.stream()
                                       .map(String::toUpperCase)
                                       .collect(Collectors.toList());

        System.out.println(upperNames);
    }
    //map() transforms each element using the given function
}
