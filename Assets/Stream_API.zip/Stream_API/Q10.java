package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q10: Find the Sum of All Numbers
//Methods Used: reduce()

public class Q10 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 20, 30);

        int sum = numbers.stream()
                         .reduce(0, Integer::sum);

        System.out.println("Sum: " + sum);
    }
    //reduce() combines all elements using the given operation (Integer::sum)
}
