package Core_Java.Stream_API_Advanced_10;

import java.util.*;
import java.util.stream.*;

//Q2: Get Names of All Employees
//Methods Used: map(), collect()

public class EmpQ2 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        List<String> names = employees.stream()
                .map(Employee::getName)
                .collect(Collectors.toList());

        System.out.println(names);
    }
    //map() transforms Employee objects to String names

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
