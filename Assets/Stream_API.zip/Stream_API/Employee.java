package Core_Java.Stream_API_Advanced_10;

public class Employee {
    private int id;
    private String name;
    private double salary;
    private String department;
    private int age;

    public Employee(int id, String name, double salary, String department, int age) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.department = department;
        this.age = age;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getSalary() { return salary; }
    public String getDepartment() { return department; }
    public int getAge() { return age; }

    @Override
    public String toString() {
        return name + " - " + salary + " - " + department;
    }
}
