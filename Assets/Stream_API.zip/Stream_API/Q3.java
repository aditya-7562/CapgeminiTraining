package Core_Java.Stream_API_Advanced_10;

import java.util.*;

//Q3: Count Numbers Greater Than 50
//Methods Used: filter(), count()

public class Q3 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 60, 70, 30, 90);

        long count = numbers.stream()
                            .filter(n -> n > 50)
                            .count();

        System.out.println("Count: " + count);
    }
    //count() returns the number of elements in the stream
}
