package Core_Java.Stream_API_Advanced_10;

import java.util.*;
import java.util.stream.*;

//Q7: Group Employees by Department
//Methods Used: collect(), groupingBy()

public class EmpQ7 {
    public static void main(String[] args) {
        List<Employee> employees = getEmployees();

        Map<String, List<Employee>> grouped = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment));

        grouped.forEach((dept, empList) -> {
            System.out.println(dept + " -> " + empList);
        });
    }
    //groupingBy() creates a Map with department as key and list of employees as value

    static List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "Varshini", 60000, "IT", 23),
                new Employee(2, "Ram", 40000, "HR", 30),
                new Employee(3, "John", 70000, "IT", 28)
        );
    }
}
